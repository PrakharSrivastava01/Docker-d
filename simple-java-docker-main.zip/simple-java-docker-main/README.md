# simple-java-docker
A simple java app that runs on docker 
